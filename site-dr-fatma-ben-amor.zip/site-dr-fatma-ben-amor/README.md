# Site — Dr. Fatma Ben Amor · Hollywood Smile Dental Clinic

Site statique en un seul fichier : `index.html` (HTML + CSS + JS, photos intégrées).
Aucune compilation nécessaire : déposez le dossier sur n'importe quel hébergement web.

## Contenu du dossier
- `index.html` — le site complet (pages : Accueil, Soins, Rendez-vous, Contact, Confidentialité, Mentions légales).
- `assets/accueil.jpg` — image d'aperçu pour les partages (balise og:image).
- `assets/photos/` — photos originales (WebP + JPG) si vous souhaitez les remplacer ou les réutiliser.

## Modifier les informations du cabinet
Tout est centralisé dans l'objet `CONFIG` au début du `<script>` de `index.html` :
- `phone`, `address`, `geo`, `instagram`, `facebook`
- `hours` : horaires (actuellement `null` → affichés « à compléter »)
- `booking.closedWeekdays`, `booking.closedDates`, `booking.preferredTimes`, `booking.motifs`

Les prestations sont dans `SERVICES` (`status: "confirmed"` = affichée).

## Champs à compléter avant la mise en ligne
Recherchez `todo` dans `index.html` : horaires, diplômes, numéro d'inscription à l'Ordre,
matricule fiscal, hébergeur, durée de conservation, date de mise à jour, crédit du portrait.

## Prise de rendez-vous
Mode actuel `booking.mode = "whatsapp"` : le site n'enregistre rien ; la demande est
préparée puis envoyée par le patient via WhatsApp. Elle n'est jamais affichée comme confirmée.

Pour brancher un backend, passez `booking.mode` à `"api"` et implémentez :
- `GET  /api/availability?month=YYYY-MM` → `{ days: { "YYYY-MM-DD": { status, slots[] } } }`
- `POST /api/appointment-requests` → `{ id, status: "pending" }`
- Admin : `GET /api/admin/requests`, `PATCH /api/admin/requests/:id`, `PUT /api/admin/availability/:date`

Pensez alors à mettre à jour la politique de confidentialité.

## Remplacer la carte
Avec votre propre hébergement, vous pouvez remplacer la carte dessinée (`[data-map]`)
par l'iframe Google Maps du cabinet.
